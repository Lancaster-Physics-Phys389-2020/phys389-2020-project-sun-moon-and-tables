Welcome to *another* student's PHYS 281 coursework. This README file is, as always, here to show you all the quirky notations I decided to use for my project. 
So, let's get right into it.

There are 7* items in total in this .zip folder.  4 .py files, 2 empty folders and this file:

README.txt : You're looking at it right now

core.py : The central module that runs the simulation and saves the data, calling classes from Vis_accel.py and Vis_planet.py

Vis_accel.py : The module that contains the Acceleration class that is used to update the accelerations of each of the bodies in the simulation. Nothing else.

Vis_planet.py : The old Particle class with a new name, Planet. Does the same thing as Particle did. Does not calculate Kinetic Energy, or Potential Energy. 
The Planet class is also used to determine the algorithm used by the simulation, either Euler Forward or Euler Cromer.

analysis.py : The analysis module that loads the saved data and prints useful results and creates plots of the data, saving those plots to empty folders, 
\Method_1 and \Method_2

Method_1 : An empty folder where all the plots for any Euler Cromer simulation will go

Method_2 : An empty folder where all the plots for any Euler Forward simulation will go

* There are 9.	  New Text Document    sits in both   Method_1    and     Method_2    so that the folders can be zipped and sent to you. They hold no information. They are
there as placeholders. They do not affect the code in any way.
---------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------

HOW TO USE THIS CODE

---------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------

1) Open core.py

2) Decide if you want to alter the bodies that are in   listofbodies    . Any body that is in   listofbodies    will be included in the simulation. If you want to
start with 12 bodies, don't change anything.

3) Run core.py in the terminal

4)i) Respond to the User Interface. It will read as follows:

---------------------------------------------------------------------------------------

What method would you like to use?
Euler Cromer = 1
Euler Forward = 2

---------------------------------------------------------------------------------------

Respond with either 1 or 2. If you respond with anything other than 1 or 2, a ValueError shall be raised.

4)ii) Once again, respond to the User Interface. It will read as shown below:

---------------------------------------------------------------------------------------

How long do you want the simulation to run for? (in years)

---------------------------------------------------------------------------------------

Respond with any number, it can be an integer or a float - the code will automatically convert it to a float. Don't choose too high. See example for a ballpark.

4)iii) More UI again. Now riddle me this:

---------------------------------------------------------------------------------------

With what timestep? (in seconds)

---------------------------------------------------------------------------------------

Once again, any number is accepted, it will be converted into a float. If the time step is greater than the total duration of the simulation, a ValueError shall
be raised.

5) Wait. The code will now run. What will be printed to the Terminal will be something like:

---------------------------------------------------------------------------------------

1% Complete, Time Remaining 29 seconds

2% Complete, Time Remaining 28 seconds

3% Complete, Time Remaining 28 seconds

---------------------------------------------------------------------------------------

If you do a very long simulation or a very short time step, it may take some time for the first "% Complete" statement to print. This is normal. The "Time Remaining"
is actually a good approximation of how long is left of the code to run, you can go and get a brew if you want.

6) Your file will now save. The screen will now print something similar to:

---------------------------------------------------------------------------------------

That took 29.250864505767822 seconds! Enjoy your file and have a nice day!


Your file is saved as Simulation_data_1000.0_1.0_12_1.npy


For use in the analysis file, you will need the name of the file, without the file extension. I suggest you copy this!

Simulation_data_1000.0_1.0_12_1

---------------------------------------------------------------------------------------

The first line prints how long the code took to run. This is mainly for bragging rights in week 9.
The second line will print the full name of the file that your simulation has been saved as. This allows you to find it in your folders.
The final line prints the name of the file without it's file extension, so it's a easier to copy to your clipboard.

The format of the save file is as so:

Simulation_data_www_xxx_yyy_zzz

www : The time step of the simulation
xxx: The length of the simulation, in years
yyy: The number of bodies in the simulation
zzz: The method used to generate the simulation

You will need to observe your FIRST and FINAL values,   www     and     zzz     , as they are relevant to how the analysis file operates.


---------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------

7) Open analysis.py

8) There is nothing to edit here. Just run the file in the Terminal!

9) Respond to the UI again. There is an example to guide you. This will load the file that you enter.

---------------------------------------------------------------------------------------

Enter the details of the file you wish to analyse, omitting the file extension.

Example input: Simulation_data_1000.0_50.0_6_1

---------------------------------------------------------------------------------------

Paste your filename in response. If you paste the EXAMPLE, you'll get a sassy retort.

10) The UI will ask you another question. This will change the names of the plots so that they have a time step that matches
your simulation. Very helpful if are scrambling a report together with minutes before the deadline.

---------------------------------------------------------------------------------------
Please enter the timestep of the file that you are analysing, it is the first value after Simulation_data.
In the example, you would enter 1000
---------------------------------------------------------------------------------------

Enter the value of your timestep as either an integer, it needs to be in this format for naming your plots.
This is the value of    www     from earlier.

11) Final question from the UI now. This response will decide the folder that the plots will be put into. Only 1 or 2 is accepted
as there are only two empty folders supplied in this .zip,      \Method_1   and     \Method_2   .

---------------------------------------------------------------------------------------

Please enter the method of the file that you are analysing, it is the final value in the filenmae.
In the example, you would enter 1

---------------------------------------------------------------------------------------

Once again, enter it as an integer. This is the value of    zzz     from before.

12)i) First, useful tabular data will print to the terminal. First values are the average & standard deviation of radii and orbits
of all of the bodies in the simulation. Following printing these values, you will be told which folder your plots are being saved
in. You will then be encouraged to have an alchoholic beverage (optional).

---------------------------------------------------------------------------------------

Mean radius of Sun's orbit is 0.0 (AU)
With standard deviation of 0.0



Mean radius of Earth's orbit is 1.0001140285146317 (AU)
With standard deviation of 0.01186130199886002

.
.
.
.
.
.

Your plots will now save to Method_1/
I hope you enjoy them! Oh and have a beer or a glass of wine, you've earned it.

---------------------------------------------------------------------------------------

Following this, a 3D plot of your simulation will be presented to you. Once this is closed, a plot of the orbital periods of the 
bodies will be shown. Once THIS is closed, a plot of the 2D paths of the orbits will be shown. And a cheeky remark.

12)ii) - 12)v) After closing the 3nd plot, you will be presented with the first of the plots created by     plotfunction    .   plotfunction    
takes several arguments, depending on the plot that you want, plots the figure AND prints the mean and standard deviation of the y
values of the plot.

---------------------------------------------------------------------------------------

Mean of % change in L (no units) is
-5.004606493444172e-13
Standard Deviation of % change in L (no units) is
3.0231699733263813e-13

---------------------------------------------------------------------------------------

At certain points between 12)ii) and 12)v), physics jokes will be printed to the terminal, to get you, the marker, through yet another student's code.
Specifically, mine.

End) The code has now completed running. The plots are saved where the code said they would be saved, should you wish to investigate them later,
or add them to your own private collection of graphs made by PHYS 281 students. Should you wish to find the mean or standard deviation of any of the
quantities that were printed, you can find them at your own leisure by scrolling through the terminal.

THANK YOU! And have a Merry Christmas and a Happy New Year.