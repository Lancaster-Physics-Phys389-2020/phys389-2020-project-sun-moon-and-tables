import numpy as np
import math
from Vis_planet import Planet
class Acceleration:
    """Class that calculates the acceleration on a body in the simulation, due to the masses of the other bodies in the system. Is called by the core module.

        Class attributes:
            ListOfBodies (list): The list of bodies in the simulation that is passed to the class
    """
    
    def __init__(self, ListOfBodies):
        """The constructor for the Acceleration class

            Arguments:
                ListOfBodies (list): The list of bodies in the simulation that is passed to the class
        """
        self.listofbodies = ListOfBodies
        
        
    def __repr__(self):
        return 'List of Bodies: %s '%(self.listofbodies)


    def accelMethod (self):
        """Method that calculates the numpy array for the acceleration of a body for the current configuration of system at that time t

            Parameters:
                G (int): The gravitational constant G
                Robins_holding_variable (ndarray): Holding variable for the for loop to iterate over
                disp (ndarray): Difference in positions of body i from the origin and body j from the origin
                magnitude (float): Magnitude of disp array
        
            Returns:
                self.listofbodies.acceleration (ndarray): The numpy array of the acceleration of each body in the self.listofbodies instance
        """
        G = 6.67408e-11
        for i in self.listofbodies:

            Robins_holding_variable = np.array([0, 0, 0])

            for j in self.listofbodies:
                
                if i == j:
                    continue
                disp = i.position - j.position
                
                magnitude = np.linalg.norm(disp)
                unit = disp/magnitude
                
                Robins_holding_variable = Robins_holding_variable -1 * G * j.mass * unit/ (magnitude * magnitude)
                
            i.acceleration = Robins_holding_variable