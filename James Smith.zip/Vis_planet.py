import numpy as np


class Planet:
    """Class that creates the instances of each body in the simulation so that the simulation can be executed.
        Class also contains the update method for each timestep of the simulation.

        Class Attributes:
                Name (str): Dummy entry for the argument passed to the constructor
                mass (int):  Dummy entry for the argument passed to the constructor
                position (list): Dummy entry for the argument passed to the constructor
                velocity (list):  Dummy entry for the argument passed to the constructor
                acceleration (list): Dummy entry for the argument passed to the constructor
                Method (int):  Dummy entry for the argument passed to the constructor

    """
    def __init__(self, initialPosition, initialVelocity, initialAcceleration, Name, mass, method):
        """The constructor for the Planet class

            Arguments:
                initialPosition (ndarray): initial position of the body when the simulation starts
                initialVelocity (ndarray): initial velocity of the body when the simulation starts
                initialAcceleration (ndarray): initial acceleration of the body when the simulation starts
                Name (string): name of the body
                mass (integer): mass of the body
                method (integer): user input method choice for the simulation to use.

        """
        self.position = np.array(initialPosition)
        self.velocity = np.array(initialVelocity)
        self.acceleration = np.array(initialAcceleration)
        self.Name = Name
        self.mass = mass
        self.setMethod(method)
        
    def __repr__(self):
        return 'Particle: %10s, Mass: %.5e, Position: %s, Velocity: %s, Acceleration:%s' %(self.Name,self.mass,self.position, self.velocity,self.acceleration)

    def setMethod(self, method):
        """Takes the user input method choice and selects either eulercromer or eulerforward to be the function that is iterated over when update is called in the core module

            Arguments:
                method (int): user input method choice for the simulation to use.

            Raises:
                ValueError: if method is not either 1 or 2
        """
        if method == 1:
            self.option = self.eulercromer
        elif method == 2:
            self.option = self.eulerforward
        else:
            raise ValueError ('What are you doing?! Method must be either 1 or 2')

    def update(self, deltaT):
        """Runs either eulercromer or eulerforward, depending on what value the user passes to setMethod

            Arguments:
                deltaT (float): Timestep of the simulation between each update
        """
        self.option(deltaT)

    def eulercromer(self, deltaT):
        """Performs the Euler Cromer update method if called

            Arguments:
                deltaT (float): Timestep of the simulation between each update
            
            Returns:
                self.position (ndarray): The numpy array of the position of the body
                self.velocity (ndarray): The numpy array of the velocity of the body
        """
        self.velocity = self.velocity + self.acceleration * deltaT #euler cromer method
        self.position = self.position + self.velocity * deltaT

    def eulerforward(self, deltaT):
        """Performs the Euler Forward update method if called

            Arguments:
                deltaT (float): Timestep of the simulation between each update
            
            Returns:
                self.position (ndarray): The numpy array of the position of the body
                self.velocity (ndarray): The numpy array of the velocity of the body
        """
        self.position = self.position + self.velocity * deltaT
        self.velocity = self.velocity + self.acceleration * deltaT #euler forward method
        
    Name = ''
    mass = 1
    position = [0,0,0]
    velocity = [0,0,0]
    acceleration = [0,0,0]
    Method = 0